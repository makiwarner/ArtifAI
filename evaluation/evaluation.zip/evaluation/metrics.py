import evaluate
import json
import os
import matplotlib.pyplot as plt
import seaborn as sns
from collections import Counter
from nltk.util import ngrams
import nltk
from nltk.tokenize import word_tokenize
import numpy as np

# Download required NLTK data
nltk.download('punkt', quiet=True)

BLEU = evaluate.load("bleu")

def plot_length_comparison(references, predictions, save_dir):
    """Plot length comparison between references and predictions."""
    ref_lengths = [len(word_tokenize(ref)) for ref in references]
    pred_lengths = [len(word_tokenize(pred)) for pred in predictions]
    
    plt.figure(figsize=(10, 6))
    plt.hist([ref_lengths, pred_lengths], label=['Reference', 'Prediction'], 
             bins=15, alpha=0.7)
    plt.xlabel('Length (words)')
    plt.ylabel('Frequency')
    plt.title('Length Distribution: Reference vs Prediction')
    plt.legend()
    plt.savefig(os.path.join(save_dir, 'length_comparison.png'))
    plt.close()

def plot_word_overlap(references, predictions, save_dir):
    """Visualize word overlap between references and predictions."""
    def get_unique_words(text_list):
        words = set()
        for text in text_list:
            words.update(set(word_tokenize(text.lower())))
        return words
    
    ref_words = get_unique_words(references)
    pred_words = get_unique_words(predictions)
    
    # Create Venn diagram data
    only_ref = len(ref_words - pred_words)
    only_pred = len(pred_words - ref_words)
    both = len(ref_words & pred_words)
    
    plt.figure(figsize=(8, 8))
    from matplotlib_venn import venn2
    venn2(subsets=(only_ref, only_pred, both), 
          set_labels=('Reference', 'Prediction'))
    plt.title('Word Overlap between References and Predictions')
    plt.savefig(os.path.join(save_dir, 'word_overlap.png'))
    plt.close()

def plot_common_ngrams(references, predictions, n=2, top_k=10, save_dir=''):
    """Plot most common n-grams in references vs predictions."""
    def get_top_ngrams(texts, n, k):
        all_ngrams = []
        for text in texts:
            tokens = word_tokenize(text.lower())
            text_ngrams = list(ngrams(tokens, n))
            all_ngrams.extend([' '.join(gram) for gram in text_ngrams])
        return Counter(all_ngrams).most_common(k)
    
    ref_ngrams = get_top_ngrams(references, n, top_k)
    pred_ngrams = get_top_ngrams(predictions, n, top_k)
    
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 10))
    
    # Reference n-grams
    ref_labels, ref_values = zip(*ref_ngrams)
    ax1.barh(range(len(ref_labels)), ref_values)
    ax1.set_yticks(range(len(ref_labels)))
    ax1.set_yticklabels(ref_labels)
    ax1.set_title(f'Top {top_k} {n}-grams in References')
    
    # Prediction n-grams
    pred_labels, pred_values = zip(*pred_ngrams)
    ax2.barh(range(len(pred_labels)), pred_values)
    ax2.set_yticks(range(len(pred_labels)))
    ax2.set_yticklabels(pred_labels)
    ax2.set_title(f'Top {top_k} {n}-grams in Predictions')
    
    plt.tight_layout()
    plt.savefig(os.path.join(save_dir, f'common_{n}grams.png'))
    plt.close()

def evaluate_model(predictions_file):
    """Evaluate model predictions with multiple metrics and visualizations."""
    # Create visualizations directory if it doesn't exist
    current_dir = os.path.dirname(os.path.abspath(__file__))
    vis_dir = os.path.join(current_dir, 'visualizations')
    os.makedirs(vis_dir, exist_ok=True)
    
    # Load predictions
    with open(predictions_file) as f:
        data = [json.loads(line) for line in f]

    references = [d["response"] for d in data]
    predictions = [d.get("prediction", "") for d in data]

    # Calculate BLEU score
    results = BLEU.compute(predictions=predictions, references=[[ref] for ref in references])
    print("BLEU score:", results)

    # Generate visualizations
    print("\nGenerating visualizations...")
    plot_length_comparison(references, predictions, vis_dir)
    try:
        plot_word_overlap(references, predictions, vis_dir)
    except ImportError:
        print("Note: matplotlib-venn not installed. Skipping word overlap visualization.")
    plot_common_ngrams(references, predictions, n=2, save_dir=vis_dir)
    
    print(f"\nVisualizations saved in: {vis_dir}")
    return results

if __name__ == "__main__":
    current_dir = os.path.dirname(os.path.abspath(__file__))
    predictions_path = os.path.join(current_dir, "generated_predictions.jsonl")
    evaluate_model(predictions_path)
